#ifndef __PCF8591_H__
#define __PCF8591_H__
unsigned char PCF8591_AD(unsigned char Address);
void PCD8591_DA(unsigned char Data);
#endif