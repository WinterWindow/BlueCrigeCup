#ifndef __CLOSE_H__
#define __CLOSE_H__
void Close();
#endif