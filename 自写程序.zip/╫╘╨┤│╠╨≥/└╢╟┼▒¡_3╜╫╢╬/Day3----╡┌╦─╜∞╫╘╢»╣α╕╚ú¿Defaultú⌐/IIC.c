#include<STC15F2K60S2.H>

sbit SDA=P2^1;
sbit SCL=P2^0;

void Delay6us()
{
	unsigned char i;
	i=14;
	while(i--);
	
}
void IIC_Start()
{
	SCL=1;
	SDA=1;
	Delay6us();
	SDA=0;
	Delay6us();
	SCL=0;
}

void IIC_Stop()
{
	SDA=0;
	SCL=1;
	Delay6us();
	SDA=1;
}

void IIC_SendByte(unsigned char Byte)
{
	unsigned char i;
	SCL=0;
	Delay6us();
	for(i=0;i<8;i++)
	{
		SDA=Byte&(0x80>>i);
		Delay6us();
		SCL=1;
		Delay6us();
		SCL=0;
		
	}
}

unsigned char IIC_ReceiveByte()
{
	unsigned char i,Byte=0x00;
	SDA=1;
	for(i=0;i<8;i++)
	{
		SCL=1;
		Delay6us();
		if(Byte){Byte|=(0x01<<i);}
		SCL=0;
		Delay6us();
	}
	return Byte;
}

void IIC_SendAck(unsigned char Ack)
{
	SCL=0;
	SDA=0;
	Delay6us();
	SDA=Ack;
	Delay6us();
	SCL=1;
	Delay6us();
	SCL=0;
}

unsigned char IIC_ReceiveAck()
{
	unsigned char Ack;
	SDA=1;
	Delay6us();
	SCL=1;
	Delay6us();
	Ack=SDA;
	Delay6us();
	SCL=0;
	return Ack;
}