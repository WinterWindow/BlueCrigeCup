#include<STC15F2K60S2.H>
#include "IIC.h"

void AT24C02_Write(unsigned char WordAddress,unsigned char Data)
{
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_ReceiveAck();
	IIC_SendByte(WordAddress);
	IIC_ReceiveAck();
	IIC_SendByte(Data);
	IIC_ReceiveAck();
	IIC_Stop();
}

unsigned char AT24C02_Read(unsigned char WordAddress)
{
	unsigned char Data;
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_ReceiveAck();
	IIC_SendByte(WordAddress);
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0xA1);
	IIC_ReceiveAck();
	Data=IIC_ReceiveByte();
	IIC_SendAck(1);
	IIC_Stop();
	return Data;
}