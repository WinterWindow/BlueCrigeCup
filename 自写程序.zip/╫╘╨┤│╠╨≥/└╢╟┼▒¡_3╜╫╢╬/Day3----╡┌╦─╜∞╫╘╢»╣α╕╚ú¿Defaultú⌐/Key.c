#include<STC15F2K60S2.H>
#include "Delay.h"

unsigned char Key()
{
	unsigned char KeyNum;
	if(P30==0){Delay(20);while(P30==0);Delay(20);KeyNum=1;}
	if(P31==0){Delay(20);while(P31==0);Delay(20);KeyNum=2;}
	if(P32==0){Delay(20);while(P32==0);Delay(20);KeyNum=3;}
	if(P33==0){Delay(20);while(P33==0);Delay(20);KeyNum=4;}
	return KeyNum;
}