#include<STC15F2K60S2.H>
#include "IIC.h"

unsigned char PCF8591_AD(unsigned char Address)
{
	unsigned char Data;
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_ReceiveAck();
	IIC_SendByte(Address);
	IIC_ReceiveAck();
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_ReceiveAck();
	Data=IIC_ReceiveByte();
	IIC_Stop();
	return Data;
}

void PCD8591_DA(unsigned char Data)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_ReceiveAck();
	IIC_SendByte(0x40);
	IIC_ReceiveAck();
	IIC_SendByte(Data);
	IIC_ReceiveAck();
	IIC_Stop();
}