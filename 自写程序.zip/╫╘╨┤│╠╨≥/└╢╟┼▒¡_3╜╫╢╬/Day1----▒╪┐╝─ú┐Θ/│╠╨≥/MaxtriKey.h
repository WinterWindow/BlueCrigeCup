#ifndef __MAXTRIKEY_H__
#define __MAXTRIKEY_H__
unsigned char MaxtriKey();
#endif