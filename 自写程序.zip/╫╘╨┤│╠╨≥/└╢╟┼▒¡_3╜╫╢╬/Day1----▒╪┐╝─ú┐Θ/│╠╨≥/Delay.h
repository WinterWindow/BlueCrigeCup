#ifndef ___H__
#define ___H__
void Delay(unsigned char ms);

#endif