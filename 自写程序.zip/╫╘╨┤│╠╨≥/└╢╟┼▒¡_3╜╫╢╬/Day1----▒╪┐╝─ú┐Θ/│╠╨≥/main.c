#include<STC15F2K60S2.H>
#include "Close.h"
#include "Nixie.h"
#include "Key.h"
#include "MaxtriKey.h"
#include "Timer0.h"
unsigned char KeyNum;
void main()
{
	Close();
	Timer0_Init();
	while(1)
	{
		KeyNum=Key();
		if(KeyNum)
		{
			if(KeyNum==1)
			{
				P2=0xA0;
				P04=1;
				P2=0X00;
			}
			if(KeyNum==2)
			{
				P2=0xA0;
				P04=0;
				P2=0X00;
			}
		}
	}
}

void Timer0_Routine() interrupt 1
{
	static unsigned char T0Counter1,T0Counter2;
	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	T0Counter1++;
	T0Counter2++;
	if(T0Counter1>=20)
	{
		T0Counter1=0;
		Key_Loop();
	}
	if(T0Counter2>=2)
	{
		T0Counter2=0;
		Nixie_Loop();
	}
}