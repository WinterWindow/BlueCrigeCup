#include<STC15F2K60S2.H>
#include "Delay.h"

//������û���ö�ʱ���Ĵ���
//unsigned char KeyNumber;
//unsigned char Key(void)
//{
//	if(P30==0){Delay(20);while(P30==0);Delay(20);KeyNumber=1;}
//	if(P31==0){Delay(20);while(P31==0);Delay(20);KeyNumber=2;}
//	if(P32==0){Delay(20);while(P32==0);Delay(20);KeyNumber=3;}
//	if(P33==0){Delay(20);while(P33==0);Delay(20);KeyNumber=4;}
//	return KeyNumber;
//}

unsigned char Key_KeyNum;

unsigned char Key_GetState()
{
	unsigned char KeyNumber=0;
	if(P30==0){KeyNumber=1;}
	if(P31==0){KeyNumber=2;}
	if(P32==0){KeyNumber=3;}
	if(P33==0){KeyNumber=4;}
	return KeyNumber;
}

void Key_Loop()
{
	static unsigned char LastState,NowState;
	LastState=NowState;
	NowState=Key_GetState();
	if(LastState==0&&NowState==1){Key_KeyNum=1;}
	if(LastState==0&&NowState==2){Key_KeyNum=2;}
	if(LastState==0&&NowState==3){Key_KeyNum=3;}
	if(LastState==0&&NowState==4){Key_KeyNum=4;}
}

unsigned char Key()
{
	unsigned char Temp;
	Temp=Key_KeyNum;
	Key_KeyNum=0;
	return Temp;
	
}