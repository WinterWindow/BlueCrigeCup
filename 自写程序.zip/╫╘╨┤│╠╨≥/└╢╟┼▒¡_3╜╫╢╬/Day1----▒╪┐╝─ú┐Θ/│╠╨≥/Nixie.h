#ifndef __Nixie_H__
#define __Nixie_H__
//ע�͵��ǲ��ö�ʱ����
//void Nixie(unsigned char Location,unsigned char Number);
void Nixie_SetBuf(unsigned char Location,unsigned char Number);
void Nixie_Loop();
#endif