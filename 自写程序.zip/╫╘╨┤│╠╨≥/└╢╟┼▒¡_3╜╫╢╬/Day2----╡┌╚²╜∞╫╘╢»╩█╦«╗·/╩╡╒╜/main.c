#include<STC15F2K60S2.H>
#include "Close.h"
#include "Timer0.h"
#include "Key.h"
#include "Nixie.h"
#include "PCF8591.h"
unsigned char KeyNum;
//Water��λ��1ml
unsigned long Water=0;
unsigned char Mode=1;//S7ģʽ��0 S6ģʽ��1
unsigned char Stop=0;
unsigned char Light;
void main()
{
	Close();
	Timer0_Init();
	while(1)
	{
		if(Mode==0)
		{
			P2=0xA0;
			P04=1;
			P06=0;
			P2=0X00;
			
			Nixie_SetBuf(5,Water/10000);
			Nixie_SetBuf(6,Water/1000%10+10);
			Nixie_SetBuf(7,Water/100%10);
			Nixie_SetBuf(8,Water/10%10);
		}
		if(Mode==1)
		{
			P2=0xA0;
			P04=0;
			P06=0;
			P2=0X00;
			
			Nixie_SetBuf(5,Water/20000);
			Nixie_SetBuf(6,Water/2000%10+10);
			Nixie_SetBuf(7,Water/200%10);
			Nixie_SetBuf(8,Water/20%10);
		}
		KeyNum=Key();
		if(KeyNum)
		{
			
					if(KeyNum==1)
					{
						if(Mode==1)
						{
							Water=0;
						}
						Mode=0;
					}
			
					if(KeyNum==2)
					{
						Mode=1;
					}
		}
		Light=PCF8591_AD(0x01);
		if(Light>64)
		{
			P2=0x80;
			P0=0xFF;
			P00=1;
			P2=0x00;
			
		}
		else
		{
			P2=0x80;
			P0=0xFF;
			P00=0;
			P2=0x00;
		}
	}
}
void Timer0_Routine() interrupt 1
{
	static unsigned char T0Counter1,T0Counter2,T0Counter3;
	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	T0Counter1++;
	T0Counter2++;
	T0Counter3++;
	if(T0Counter1>=20)
	{
		T0Counter1=0;
		Key_Loop();
	}
	if(T0Counter2>=2)
	{
		T0Counter2=0;
		Nixie_Loop();
	}
	if(Mode==0&&Stop==0)
	{
			if(T0Counter3>=100)
			{
				T0Counter3=0;
				Water=Water+10;
				if(Water>=99990)
				{
					Stop=1;
					Mode=1;
				}
			}
	}
	
}