#include<STC15F2K60S2.H>
#include "Delay.h"

unsigned char Buf[]={0,20,10,5,0,0,10,0,0};
//0 1 2 3 4 5 6 7 8
unsigned char LocationTable[]={0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
//0 1 2 3 4 5 6 7 8 9 0. 1. 2. 3. 4. 5. 6. 7. 8. 9.  " "
unsigned char NumberTable[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90,
															0X40,0X79,0X24,0X30,0X19,0X12,0X02,0X78,0X00,0X10,0xFF};
//����ǲ��ö�ʱ����
/*
void Nixie(unsigned char Location,unsigned char Number)
{
	P2=0xC0;
	P0=LocationTable[Location];
	
	P2=0xE0;
	P0=NumberTable[Number];
	Delay(1);
	P2=0X00;
}
*/
void Nixie_SetBuf(unsigned char Location,unsigned char Number)
{
	Buf[Location]=Number;
}
void Nixie_Scan(unsigned char Location,unsigned char Number)
{
	P2=0xC0;
	P0=LocationTable[Location];
	
	P2=0xE0;
	P0=NumberTable[Number];
	Delay(1);
	P2=0X00;
}


void Nixie_Loop()
{
	  static unsigned char i=1;
	  Nixie_Scan(i,Buf[i]);
	  i++;
	  if(i>8)
		{
		i=1;
		}
		
}