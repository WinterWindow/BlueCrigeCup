#include<STC15F2K60S2.H>
sbit IIC_SDA=P2^1;
sbit IIC_SCL=P2^0;
void Delay6us()		
{
	unsigned char i;

	i = 14;
	while (--i);
}

void IIC_Start()
{
	IIC_SCL=1;
	IIC_SDA=1;
	Delay6us();
	IIC_SDA=0;
	Delay6us();
	IIC_SCL=0;
}
void IIC_Stop()
{
	IIC_SCL=0;
	IIC_SDA=0;
	Delay6us();
	IIC_SDA=1;
	Delay6us();
	IIC_SCL=1;
}
void IIC_SendByte(unsigned char Byte)
{
	unsigned char i;
	
	for(i=0;i<8;i++)
	{
		IIC_SDA=Byte&(0x80>>i);
		Delay6us();
		IIC_SCL=1;
		Delay6us();
		IIC_SCL=0;
	}
}
unsigned char IIC_ReceiveByte()
{
	unsigned char i,Byte;
	IIC_SDA=1;
	IIC_SCL=0;
	for(i=0;i<8;i++)
	{
		IIC_SCL=1;
		Delay6us();
		if(IIC_SDA){Byte|=(0x80<<i);}
		Delay6us();
		IIC_SCL=0;
		Delay6us();
	}
	return Byte;
}
void IIC_SendAck(unsigned char AckBit)
{
	IIC_SCL=0;
	IIC_SDA=AckBit;
	Delay6us();
	IIC_SCL=1;
	Delay6us();
	IIC_SCL=0;
}
unsigned char IIC_ReceiveAck()
{
	unsigned char AckBit;
	IIC_SDA=1;
	IIC_SCL=0;
	Delay6us();
	IIC_SCL=1;
	Delay6us();
	AckBit=IIC_SDA;
	Delay6us();
	IIC_SCL=0;
	return AckBit;
}