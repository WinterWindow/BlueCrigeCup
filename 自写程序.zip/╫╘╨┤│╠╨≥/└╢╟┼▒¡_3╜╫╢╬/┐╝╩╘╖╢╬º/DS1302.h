#ifndef __DS1302_H__
#define __DS1302_H__

extern char DS1302_Time[];
void DS1302_Init();
void DS1302_WriteTime();
void DS1302_ReadTime();
#endif