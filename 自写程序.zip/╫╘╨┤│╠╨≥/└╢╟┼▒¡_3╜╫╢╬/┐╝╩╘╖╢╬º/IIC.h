#ifndef __IIC_H_
#define __IIC_H_
void IIC_Start();
void IIC_Stop();
void IIC_SendByte(unsigned char Byte);
unsigned char IIC_ReceiveByte();
void IIC_SendAck(unsigned char AckBit);
unsigned char IIC_ReceiveAck();
#endif