#include<STC15F2K60S2.H>
#include "Delay.h"
#define L1 P30
#define L2 P31
#define L3 P32
#define L4 P33

#define C1 P44
#define C2 P42
#define C3 P35
#define C4 P34

unsigned char Keys()
{
	unsigned char Keys=20;
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L1=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);Keys=0;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);Keys=1;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);Keys=2;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);Keys=20;}
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L2=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);Keys=3;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);Keys=4;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);Keys=5;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);Keys=20;}
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L3=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);Keys=6;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);Keys=7;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);Keys=8;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);Keys=20;}
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L4=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);Keys=9;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);Keys=10;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);Keys=11;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);Keys=20;}
	
	return Keys;
	
}