#include<STC15F2K60S2.H>
#include "DS13B20.h"
#include "Keys.h"
#include "Nixie.h"
#include "Delay.h"
#include "Timer0.h"
unsigned char KeyNum=0;
unsigned char T,TMAX=30,TMIN=20;
unsigned char Count=0;
bit L2=0;//0��ʾ������ 1��ʾ����
bit Mode=0;
void ShowT();
void SetT();

void main()
{
	//�ر�û�漰�����豸
	P2=0X80;
	P0=0xFF;
	
	P2=0xA0;
	P0=0x00;
	
	Timer0Init();
	DS18B20_ConvertT();
	Delay(1000);
	
	while(1)
	{
		T=(int)DS18B20_ReadT();
		KeyNum=Keys();
		if(KeyNum!=20)
		{
			if(KeyNum==10)
			{
				Mode=!Mode;
			}
			if(Mode==1)
			{
				if(KeyNum<=9&&KeyNum>=0)
				{
					
					if(Count==0)
					{
						TMAX=KeyNum*10;
					}
					if(Count==1)
					{
						TMAX=TMAX+KeyNum;
					}
					if(Count==2)
					{
						TMIN=KeyNum*10;
					}
					if(Count==3)
					{
						TMIN=TMIN+KeyNum;
					}
					Count++;
					if(Count>=4)
					   Count=0;
				}
				if(KeyNum==11)
				{
					TMAX=0;
					TMIN=0;
					Count=0;
				}
				//��������¶Ȳ��Ծ� L2��
				if(TMAX<=TMIN)
				{

					L2=1;
				}
				//���� L2�ر�
				else
				{

					L2=0;
				}
			}
			
		}
		if(Mode==0)
		{
			ShowT();
		}
		if(Mode==1)
		{
			SetT();
		}
	}
}
void ShowT()
{
	unsigned char n;
	//�̵����ر� L1��0.8s ��˸
	if(T<TMIN)
	{
		n=0;
		P2=0xA0;
		P0=0x00;
	}
	//�̵����ر� L1��0.4s ��˸
	else if(T<=TMAX&&T>=TMIN)
	{
		n=1;
		P2=0xA0;
		P0=0x00;
	}
	//�̵����� L1��0.2s ��˸
	else
	{
		n=2;
		P2=0xA0;
		P0=0x10;
	}
	Nixie(1,10);
	Nixie(2,n);
	Nixie(3,10);
	Nixie(4,11);
	Nixie(5,11);
	Nixie(6,11);
	Nixie(7,T/10);
	Nixie(8,T%10);
}
void SetT()
{
	Nixie(1,10);
	Nixie(2,TMAX/10);
	Nixie(3,TMAX%10);
	Nixie(4,11);
	Nixie(5,11);
	Nixie(6,10);
	Nixie(7,TMIN/10);
	Nixie(8,TMIN%10);
}
void Timer0_Routine() interrupt 1
{
	static unsigned int T0Count;//����ȫ�ֱ��� �Ǿֲ���̬���� �˳�֮���ǻ�ռ�ݿռ� �����ͷ� ������һ�ε�ֵ
	unsigned char n;
	TH0=0XFC;//65535/256
	TL0=0X18;//65535%256+1
	T0Count++;
	if(T<TMIN)
		n=8;
	else if(T<=TMAX&&T>=TMIN)
		n=4;
	else
		n=2;
	if(T0Count>=n*100)
	{
			T0Count=0;
			P2=0x80; //ѡ��LED
		  P0|=0xFE;//1111 1110
		  P00=~P00;
		  	if(L2==1)
				{
				P01=0;
				}
				if(L2==0)
				{
					P01=1;
				}
	}

}