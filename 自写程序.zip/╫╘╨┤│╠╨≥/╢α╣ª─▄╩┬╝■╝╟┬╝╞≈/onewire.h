#ifndef __ONEWIRE_H
#define __ONEWIRE_H

float ReadTemp();

#endif