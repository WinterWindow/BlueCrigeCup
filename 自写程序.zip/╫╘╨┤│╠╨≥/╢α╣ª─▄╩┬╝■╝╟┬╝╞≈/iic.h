#ifndef _IIC_H
#define _IIC_H

void IIC_Start(); 
void IIC_Stop();  
bit IIC_WaitAck();  

void IIC_SendByte(unsigned char byt); 
unsigned char IIC_RecByte(); 

void ADWrite(unsigned char addr);
unsigned char ADRead(unsigned char addr);

unsigned char At24c02Read(unsigned char addr);
void  At24c02Write(unsigned char addr,unsigned char val);

#endif