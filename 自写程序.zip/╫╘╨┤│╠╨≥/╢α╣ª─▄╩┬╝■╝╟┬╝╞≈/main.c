#include "stc15f2k60s2.h"
#include "onewire.h"
#include "iic.h"
#include "ds1302.h"
typedef unsigned char u8;
typedef unsigned int u16;
u8 code ledguan[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
u8 display_mode,disp[8],wei_xuan,key_count,scan_count,temp,ad1,ad2,dat[8],dat_count,flag2,at_flag;
u16 stop_time,stop_count,uart_count;
bit flag1,flag3,flag4,flag5;

void delay(u16 i);
u8 KeyScan();
void Show0();
void Show1();
void Show2();
void Light();
void SendByte(u8 byte);

void Scan();
void Timer0Init();
void Uart1Init();
void Step0();
void Step4();
void Step5();

void main()
{
	P2=0x80;P0=0xff;P2=0x00;
	P2=0xa0;P0=0x00;P2=0x00;
	Ds1302Init();
	Timer0Init();
	Uart1Init();
	while(1)
	{
		if(key_count>=10)
		{
			key_count=0;
			switch(KeyScan())
			{
				case(0):Step0();break;
				case(4):Step4();break;
				case(5):Step5();break;
			}
			
		}
		Scan();
	}
	
	
}

void delay(u16 i)
{
	u8 k;
	while(i--)
	  for(k=0;k<12;k++);
	
}

u8 KeyScan()
{
	static u8 key_state;
	u8 keyvalue;
	switch(key_state)
	{
		case(0):keyvalue=0;
		        if(P33==0||P32==0||P31==0||P30==0)
						key_state=1;
						break;
		case(1):if(P33==0||P32==0||P31==0||P30==0)
						{
							key_state=2;
							if(P33==0) keyvalue=4;
							else if(P32==0) keyvalue=5;
							else if(P31==0) keyvalue=6;
							else if(P30==0) keyvalue=7;
						}
						else
						{
							keyvalue=0;
							key_state=0;
						}
						break;
		case(2):keyvalue=0;
			      if(P33==1&&P32==1&&P31==1&&P30==1)
		        key_state=0;
						break;
	}
	return keyvalue;
}



void Show0()
{
	disp[0]=ledguan[temp/10];
	disp[1]=ledguan[temp%10];
	disp[2]=0xc6;
	disp[3]=0xff;
	disp[4]=0xff;
	disp[5]=ledguan[ad2/10];
	disp[6]=ledguan[ad2%10];
	disp[7]=0x89;
	
}

void Show1()
{
	
	disp[0]=ledguan[Time[2]/16];
	disp[1]=ledguan[Time[2]%16];
	
  disp[3]=ledguan[Time[1]/16];
	disp[4]=ledguan[Time[1]%16];
	
	disp[6]=ledguan[Time[0]/16];
	disp[7]=ledguan[Time[0]%16];
	
}

void Show2()
{
	disp[0]=0xff;
	disp[1]=0xff;
	disp[2]=0xff;
	disp[3]=0xbf;
	disp[4]=ledguan[stop_time%10000/1000];
	disp[5]=ledguan[stop_time%1000/100];
	disp[6]=ledguan[stop_time%100/10];
	disp[7]=ledguan[stop_time%10];
}

void Light()
{
	P0=0xff;
	if(flag1==0) P0&=0xfe;
	else P0&=0xfd;
	
	if(flag2) P0&=0xfb;
	P2=0x80;P2=0x00;
}

void SendByte(u8 byte)
{
	SBUF=byte;
	while(!TI);
	TI=0;
}















void Scan()
{
	u8 k;
	if(scan_count>=100)
	{
		scan_count=0;
		temp=ReadTemp();
		
		
		ET0=0;
		ad2=ADRead(0x01)*1.0*99/255;  
		ET0=1;
		delay(500);
		ET0=0;
		ad1=ADRead(0x03);
		ET0=1;
		
	}
	
	if(ad1<160&&flag2==0)
	{

			stop_count=0;
			stop_time=0;
			flag2=1;
	}
	else if(ad1>160) 
	{
		if(flag2)
		{
		  flag2=0;
			ET0=0;At24c02Write(1+11*at_flag,temp/10);ET0=1;delay(1000);
			ET0=0;At24c02Write(2+11*at_flag,temp%10);ET0=1;delay(1000);
			ET0=0;At24c02Write(3+11*at_flag,ad2/10);ET0=1;delay(1000);
			ET0=0;At24c02Write(4+11*at_flag,ad2%10);ET0=1;delay(1000);
			ET0=0;At24c02Write(5+11*at_flag,Time[2]/16);ET0=1;delay(1000);
			ET0=0;At24c02Write(6+11*at_flag,Time[2]%16);ET0=1;delay(1000);
			ET0=0;At24c02Write(7+11*at_flag,Time[1]/16);ET0=1;delay(1000);
			ET0=0;At24c02Write(8+11*at_flag,Time[1]%16);ET0=1;delay(1000);
			ET0=0;At24c02Write(9+11*at_flag,Time[0]/16);ET0=1;delay(1000);
			ET0=0;At24c02Write(10+11*at_flag,Time[0]%16);ET0=1;delay(1000);
			ET0=0;At24c02Write(11+11*(at_flag++),stop_time);ET0=1;
			at_flag=at_flag%5;
		}
	}
	
	if(uart_count>=1000)
	{
		uart_count=0;
		if(flag1==0&&flag3==1)
		{
			SendByte('{');SendByte('0'+temp/10);SendByte('0'+temp%10);SendByte('-');SendByte('0'+ad2/10);SendByte('0'+ad2%10);
			SendByte('%');SendByte('}');SendByte('{');SendByte('0'+Time[2]/16);SendByte('0'+Time[2]%16);SendByte('-');
			SendByte('0'+Time[1]/16);SendByte('0'+Time[1]%16);SendByte('-');SendByte('0'+Time[0]/16);SendByte('0'+Time[0]%16);
			SendByte('}');SendByte('{');SendByte('0'+flag2);SendByte('}');SendByte('\r');SendByte('\n');
		}
	}
	
	if(flag1==1&&flag3==1)
	{
		flag3=0;
		for(k=0;k<5;k++)
		{
			
			
			SendByte('{');SendByte('0'+At24c02Read(1+11*k));SendByte('0'+At24c02Read(2+11*k));SendByte('-');SendByte('0'+At24c02Read(3+11*k));SendByte('0'+At24c02Read(4+11*k));
			SendByte('%');SendByte('}');SendByte('{');SendByte('0'+At24c02Read(5+11*k));SendByte('0'+At24c02Read(6+11*k));SendByte('-');
			SendByte('0'+At24c02Read(7+11*k));SendByte('0'+At24c02Read(8+11*k));SendByte('-');SendByte('0'+At24c02Read(9+11*k));SendByte('0'+At24c02Read(10+11*k));
			SendByte('}');SendByte('{');SendByte('0'+At24c02Read(11+11*k));SendByte('}');SendByte('\r');SendByte('\n');
		}
		
	}
	
	if(dat[0]=='A'&&flag5)
	{
		flag5=0;
		delay(5000);
		if(dat[5]!='S')
		{
			dat_count=0;
			flag3=0;
		}
		
	}
	
	ET0=0;
	Ds1302Read();
	ET0=1;
}

void Timer0Init()
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD = 0x00;		//���ö�ʱ��ģʽ
	TL0 = 0x20;		//���ö�ʱ��ֵ
	TH0 = 0xD1;	
	EA=1;
	ET0=1;
	TR0=1;
	
}

void Uart1Init()
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x40;		//��ʱ��1ʱ��ΪFosc,��1T
	AUXR &= 0xFE;		//����1ѡ��ʱ��1Ϊ�����ʷ�����
	TMOD = 0x00;		//�趨��ʱ��1Ϊ16λ�Զ���װ��ʽ
	TL1 = 0x3C;		//�趨��ʱ��ֵ
	TH1 = 0xF6;	//�趨��ʱ��ֵ
	ET1 = 0;		//��ֹ��ʱ��1�ж�
	TR1 = 1;		//������ʱ��1
	ES = 1;                     //ʹ�ܴ����ж�
  EA = 1;
}

void Step0()
{
	switch(display_mode)
	{
		case(0):Show0();break;
		case(1):Show1();break;
		case(2):Show2();break;
	}
	
}

void Step4()
{
	flag1=~flag1;
}

void Step5()
{
	switch(display_mode)
	{
		case(0):display_mode=1;break;
		case(1):display_mode=2;break;
		case(2):display_mode=0;break;
	}
	
}



void Timer0() interrupt 1
{
	static u16 smg_count,link_count,light_count;
	smg_count++;key_count++;scan_count++;link_count++;stop_count++;light_count++;uart_count++;
	
	if(light_count>=10)
	{
		Light();
		
	}
	
	if(flag2&&stop_count>=1000)
	{
		stop_count=0;
		stop_time++;
	}
	
	if(display_mode==1)
	{
		if(link_count>=2000)
	{
		link_count=0;
		disp[2]=0xff;
		disp[5]=0xff;
	}
	else if(link_count>=1000)
	{
		disp[2]=0xbf;
		disp[5]=0xbf;
		
	}
	}
	
	if(smg_count>=2)
	{
		smg_count=0;
		P2=0xe0;P0=0xff;P2=0x00;
		P2=0xc0;P0=1<<wei_xuan;P2=0x00;
		P2=0xe0;P0=disp[wei_xuan++];P2=0x00;
		wei_xuan=wei_xuan%8;
	}
	
}

void Uart() interrupt 4
{
	if(RI)
	{
		RI=0;
		dat[dat_count++]=SBUF;	
		switch(dat_count)
		{
			case(1):if(dat[0]!='A') 
			{
				      dat_count=0;flag3=0;
			}
			else
			{
				flag5=1;
				dat[5]=0;
			}
			break;
			case(2):if(dat[1]!='A') 	
				{
				      dat_count=0;flag3=0;
			  }break;
			case(3):if(dat[2]!='A') 	
				{
				      dat_count=0;flag3=0;
			  }break;
			case(4):if(dat[3]!='S') 	
				{
				      dat_count=0;flag3=0;
			  }break;
			case(5):if(dat[4]!='S') 	
				{
				      dat_count=0;flag3=0;
			  }break;
			case(6):if(dat[5]=='S') 
							{
								flag3=1;
							}
				      dat_count=0;
			        break;
		}
	}
	
}