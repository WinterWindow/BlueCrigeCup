/*
  ����˵��: DS1302��������
  ��������: Keil uVision 4.10 
  Ӳ������: CT107��Ƭ���ۺ�ʵѵƽ̨ 8051��12MHz
  ��    ��: 2011-8-9
*/

#include <reg52.h>
#include <intrins.h>
#include "ds1302.h"
typedef unsigned char u8;
typedef unsigned int u16;
sbit SCK=P1^7;		
sbit SDA=P2^3;		
sbit RST = P1^3;   // DS1302��λ			

u8 code WriteAddr[]={0x80,0x82,0x84};
u8 code ReadAddr[]={0x81,0x83,0x85};
u8 Time[]={0x55,0x59,0x23};

void Write_Ds1302(unsigned  char temp) 
{
	unsigned char i;
	for (i=0;i<8;i++)     	
	{ 
		SCK=0;
		SDA=temp&0x01;
		temp>>=1; 
		SCK=1;
	}
}   

void Write_Ds1302_Byte( unsigned char address,unsigned char dat )     
{
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1; 	_nop_();  
 	Write_Ds1302(address);	
 	Write_Ds1302(dat);		
 	RST=0; 
}

unsigned char Read_Ds1302_Byte ( unsigned char address )
{
 	unsigned char i,temp=0x00;
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1;	_nop_();
 	Write_Ds1302(address);
 	for (i=0;i<8;i++) 	
 	{		
		SCK=0;
		temp>>=1;	
 		if(SDA)
 		temp|=0x80;	
 		SCK=1;
	} 
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
	SCK=1;	_nop_();
	SDA=0;	_nop_();
	SDA=1;	_nop_();
	return (temp);			
}


void Ds1302Init()
{
	u8 k;
	Write_Ds1302_Byte( 0x8e,0x00) ;
	for(k=0;k<3;k++)
	Write_Ds1302_Byte( WriteAddr[k],Time[k]) ;
	Write_Ds1302_Byte( 0x8e,0x80) ;
	
}

void Ds1302Read()
{
	u8 k;
	for(k=0;k<3;k++)
	Time[k]=Read_Ds1302_Byte (ReadAddr[k] );
	
}











