#include<STC15F2K60S2.H>
#include "Delay.h"


void main()
{
	unsigned char i,j;
	unsigned char LED=0x01;
	P2=0xA0;
	P0=0x00;
	P2=0x80;
	P0=0xFF;
	
	while(1)
	{
		P2=0x80;
		for(i=0;i<8;i++)
		{
			
			for(j=0;j<8-i;j++)
			{
				P0=~(LED<<j);
				Delay(300);
			}
			LED=(LED<<1)|0x01;
		}
		LED=0x01;
	}
}