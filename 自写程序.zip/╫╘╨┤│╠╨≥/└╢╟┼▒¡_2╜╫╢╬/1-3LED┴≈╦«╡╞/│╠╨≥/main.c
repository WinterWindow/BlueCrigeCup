#include<STC15F2K60S2.H>
#include "Delay.h"
void main()
{
	unsigned char i;
	P2=0x80;
	P0=0xFF;
	P2=0xA0;
	P0=0x00;
    while(1)
   {
		 P2=0x80;
			for(i=0;i<8;i++)
		 {
			 P0=~(0x01<<i);
			 Delay(500);
		 }
		 
   }
}