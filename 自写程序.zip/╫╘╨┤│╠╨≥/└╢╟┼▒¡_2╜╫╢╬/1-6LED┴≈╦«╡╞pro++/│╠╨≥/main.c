#include<STC15F2K60S2.H>
#include "Delay.h"


void main()
{
	 char i,j;
	unsigned char LED=0x01;
	P2=0xA0;
	P0=0x00;
	P2=0x80;
	P0=0xFF;
	
		P2=0x80;
		for(i=0;i<3;i++)
		{
			for(j=0;j<8;j=j+2)
			{
				P0=~(0x01<<j);
				Delay(300);
			}
			for(j=1;j<8;j=j+2)
			{
				P0=~(0x01<<j);
				Delay(300);
			}
		}
		for(i=0;i<3;i++)
		{
			for(j=0;j<8;j++)
			{
				P0=~(0x01<<j);
				Delay(300);
			}
			for(j=0;j<8;j++)
			{
				P0=~(0x80>>j);
				Delay(300);
			}
		}
		
		
	for(i=0;i<3;i++)
		{
			for(j=0;j<4;j++)
			{
				P0=~((0x01<<j)|(0x80>>j));
				Delay(300);
			}
			
		}
	for(i=0;i<3;i++)
		{
			for(j=3;j>=0;j--)
			{
				P0=~((0x01<<j)|(0x80>>j));
				Delay(300);
			}
		}
		//0001 1000
		//0010 0100
		//0100 0010
		//1000 0001
}