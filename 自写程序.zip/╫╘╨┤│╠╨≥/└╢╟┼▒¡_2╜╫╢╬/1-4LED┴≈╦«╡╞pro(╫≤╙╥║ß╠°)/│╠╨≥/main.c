#include<STC15F2K60S2.H>
#include "Delay.h"
void main()
{
	unsigned char i,j;
	P2=0x80;
	P0=0xFF;
	P2=0xA0;
	P0=0x00;
    while(1)
   {
		 P2=0x80;
		 for(j=0;j<2;j++)
		 {
				for(i=0;i<8;i++)
			 {
				 P0=~(0x01<<i);
				 Delay(200);
			 }
				for(i=0;i<8;i++)
			 {
				 P0=~(0x80>>i);
				 Delay(200);
			 }
		 }
		 P0=0xFF;
		 Delay(300);
		 for(j=0;j<5;j++)
		 {
			 P0=~P0;
			 Delay(300);
			 P0=~P0;
			 Delay(300);
		 }
   }
}