#include<STC15F2K60S2.H>
#include "Delay.h"

void main(void)
{
	P2 =0xA0;
	P0 =0x00;
	
	P2 =0x80;
	P0 =0xFF;
	while(1)
	{
		P2 = 0x80;
		P00=1;
		Delay(200);
		
		P2 = 0x80;
		P00=0;
		Delay(200);
	}
	
}