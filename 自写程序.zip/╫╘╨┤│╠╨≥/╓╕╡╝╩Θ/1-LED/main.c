#include <STC15F2K60S2.H>
#include "LED.h"
void main()
{
	Cls();
	while(1)
	{
		LED(0x11);
	}
	
}
