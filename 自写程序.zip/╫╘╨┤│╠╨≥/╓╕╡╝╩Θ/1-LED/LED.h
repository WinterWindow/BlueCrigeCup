#ifndef __LED_H__
#define __LED_H__
void Cls(void);
void LED(unsigned char ucLed);
#endif