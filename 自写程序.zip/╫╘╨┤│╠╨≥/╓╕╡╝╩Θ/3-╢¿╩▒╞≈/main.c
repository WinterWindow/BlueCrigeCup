#include <STC15F2K60S2.H>
#include "LED.h"
#include "tim.h"
unsigned char ucSec;
unsigned long ulms;

void main()
{
	Cls();
	Timer1Init();
	while(1);
}
void Timer1_1(void) interrupt 3
{
	TL1 = 0x18;		//���ö�ʱ��ֵ
	TH1 = 0xFC;		//���ö�ʱ��ֵ
	ulms++;
	if(ulms>=1000)
	{
		ulms=0;
		ucSec++;
	}
	LED(ucSec);
}