#ifndef __TIM_H__
#define __TIM_H__
void Timer1Init();
#endif