#include <STC15F2K60S2.H>
#include "LED.h"
#include "Nixie.h"
#include "tim.h"
#include "stdio.h"
unsigned char ucLed,ucSec;
unsigned char pucSeg_Buf[9], pucSeg_Code[8],ucSeg_Pos;
unsigned long ulms;
void main()
{
	Cls();
	Timer1Init();
	while(1)
	{
		sprintf(pucSeg_Buf,"   %04u",(unsigned int)ucSec);
		Nixie_Tran(pucSeg_Buf,pucSeg_Code);
	}
	
}
void Timer_1(void) interrupt 3
{
	TL1 = 0x18;		//���ö�ʱ��ֵ
	TH1 = 0xFC;		//���ö�ʱ��ֵ
	ulms++;
	if(ulms>=1000)
	{
		ulms=0;
		ucSec++;
	}
	Seg_Disp(pucSeg_Code,ucSeg_Pos);
	if(++ucSeg_Pos==8)ucSeg_Pos=0;
}