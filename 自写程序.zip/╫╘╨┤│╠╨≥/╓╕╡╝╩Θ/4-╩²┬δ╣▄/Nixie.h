#ifndef __NIXIE_H__
#define __NIXIE_H__
void Nixie_Tran(unsigned char *pucSeg_Buf,unsigned char *pucSeg_Code);
void Seg_Disp(unsigned char *pucSeg_Code,unsigned char ucSeg_Pos);
#endif