#ifndef __Buzzer_H__
#define __Buzzer_H__

void Buzzer_Time(unsigned int ms);

#endif