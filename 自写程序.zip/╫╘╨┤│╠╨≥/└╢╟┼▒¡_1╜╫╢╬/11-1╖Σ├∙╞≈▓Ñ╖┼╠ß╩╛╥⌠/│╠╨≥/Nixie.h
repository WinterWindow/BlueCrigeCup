#ifndef __NIXIE_H__
#define __NIXIE_H__

void Nixie(unsigned int Location,Number);

#endif