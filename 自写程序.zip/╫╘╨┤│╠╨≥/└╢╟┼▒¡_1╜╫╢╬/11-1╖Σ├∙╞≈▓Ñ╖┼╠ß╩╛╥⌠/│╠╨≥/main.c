#include<STC15F2K60S2.H>
#include "Delay.h"
#include "Nixie.h"
#include "Key.h"
#include "Buzzer.h"
sbit Buzzer=P0^6;
unsigned char KeyNum;
void main()
{
	 Buzzer=0;
    while(1)
   {
		 KeyNum=Key();
		 if(KeyNum)
		 {
			 Buzzer_Time(5000);
		 }
   }
}