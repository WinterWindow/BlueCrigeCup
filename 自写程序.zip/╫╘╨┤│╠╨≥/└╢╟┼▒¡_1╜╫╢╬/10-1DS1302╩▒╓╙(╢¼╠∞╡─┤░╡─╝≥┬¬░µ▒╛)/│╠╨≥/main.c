#include<STC15F2K60S2.H>
#include "LCD1602.h"
#include "DS1302.h"
#include "Delay.h"
unsigned char Second,Minute,Hour,Date,Month,Year;

void main()
{
		LCD_Init();
		DS1302_Init();
	  DS1302_WriteByte(0x8E,0x00);//���д����
	  DS1302_WriteByte(0x8C,0x21);//��
		DS1302_WriteByte(0x88,0x01);//��
		DS1302_WriteByte(0x86,0x20);//��
		DS1302_WriteByte(0x84,0x13);//Сʱ
		DS1302_WriteByte(0x82,0x20);//����
		DS1302_WriteByte(0x80,0x30);//��
		
    while(1)
   {
		   Year=DS1302_ReadByte(0x8D);
		   Month=DS1302_ReadByte(0x89);
			 Date=DS1302_ReadByte(0x87);
		   Hour=DS1302_ReadByte(0x85);
		   Minute=DS1302_ReadByte(0x83);
       Second=DS1302_ReadByte(0x81);
		   
		   LCD_ShowNum(1,1,20,2);
			 LCD_ShowNum(1,3,Year/16*10+Year%16,2);
		   LCD_ShowChar(1,5,' ');
		 
			 LCD_ShowNum(1,6,Month/16*10+Month%16,2);
		   LCD_ShowChar(1,8,' ');
		 
		   LCD_ShowNum(1,9,Date/16*10+Date%16,2);
		 
		   LCD_ShowNum(2,1,Hour/16*10+Hour%16,2);
		   LCD_ShowChar(2,3,':');
		 
		   LCD_ShowNum(2,4,Minute/16*10+Minute%16,2);
			 LCD_ShowChar(2,6,':');
			 
		   LCD_ShowNum(2,7,Second/16*10+Second%16,2);
		   Delay(1000);
   }
}