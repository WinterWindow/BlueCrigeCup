#ifndef __CLS_H__
#define __CLS_H__

void cls();

#endif