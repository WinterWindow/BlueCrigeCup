#include<STC15F2K60S2.H>
#include "Delay.h"
#include "Nixie.h"
#include "Cls.h"
void main()
{
	cls();
	while(1)
	{
		Nixie(1,1);
		Nixie(2,2);
	};
}