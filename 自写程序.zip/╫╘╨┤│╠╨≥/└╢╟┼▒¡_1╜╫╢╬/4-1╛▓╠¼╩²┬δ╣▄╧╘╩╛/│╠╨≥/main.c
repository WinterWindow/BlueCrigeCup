#include<STC15F2K60S2.H>
#include<INTRINS.H>
void cls_buzz()
{
	P2=(P2&0X1F)|0XA0;
	P0=0X00;
	P2=P2&0X1F;
}
void Nixie(unsigned int Location,Number)
{
	P2=(P2&0X1F)|0XC0;
	switch(Location)
	{
		case 1:P0=0X01;break;
		case 2:P0=0X02;break;
		case 3:P0=0X04;break;
		case 4:P0=0X08;break;
		case 5:P0=0X10;break;
		case 6:P0=0X20;break;
		case 7:P0=0X40;break;
		case 8:P0=0X80;break;
	}
	
	P2=P2&0X1F;
	
	//ѡ������
	P2=(P2&0X1F)|0XE0;
	switch(Number)
	{
		case 0:P0=0XC0;break;
		case 1:P0=0XF9;break;
		case 2:P0=0XA4;break;
		case 3:P0=0XB0;break;
		case 4:P0=0X99;break;
		case 5:P0=0X92;break;
		case 6:P0=0X82;break;
		case 7:P0=0XF8;break;
		case 8:P0=0X80;break;
		case 9:P0=0X90;break;
		//&0X7F;//�ӵ�
	}
	P2=P2&0X1F;
	
}
void main()
{
	cls_buzz();
	Nixie(5,1);
	while(1)//ע�� ����Ҫ��while ���ǲ�֪��Ϊʲô
	{};
}