#include<STC15F2K60S2.H>
#include "Delay.h"
#include "Timer0.h"
#include "Nixie.h"
#include "Key.h"
sbit DA=P0^0;
unsigned int Count,Compare;
unsigned char i;
void main()
{
	Timer0Init();
	Compare=5;
	P2=0x80;
	P0=0xFF;
    while(1)
   {
		 for(i=0;i<100;i++)
		 {
			 Compare=i;
			 Delay(20);
		 }
		 for(i=0;i<100;i++)
		 {
			 Compare=100-i;
			 Delay(20);
		 }
   }
}
void Timer0_Routine() interrupt 1
{
	static unsigned int T0counter;
	TL0 = 0x9C;		//���ö�ʱ��ֵ
	TH0 = 0xFF;		//���ö�ʱ��ֵ
	Count++;
	Count%=100;
	T0counter++;
	if(Count<Compare)
	{
		DA=0;
	}
	else
	{
		DA=1;
	}
	
}