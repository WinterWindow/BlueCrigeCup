#include<STC15F2K60S2.H>
#include "Delay.h"
#include "Timer0.h"
#include "Nixie.h"
#include "Key.h"
sbit Motor=P0^0;
unsigned int Count,Compare;
unsigned char Speed,KeyNum;
void main()
{
	Timer0Init();
	P2=0x80;
	P0=0xFF;
	
	P2=0xE0;
	P0=0x00;
	
	P2=0xA0;
	P0=0x00;
    while(1)
   {
		 KeyNum=Key();
		 if(KeyNum==1)
		 {
			 Speed++;
			 Speed%=4;
			 if(Speed==0){Compare=0;}
			 if(Speed==1){Compare=5;}
			 if(Speed==2){Compare=50;}
			 if(Speed==3){Compare=80;}
		 }
		 Nixie(1,Speed);
   }
}
void Timer0_Routine() interrupt 1
{
	static unsigned int T0counter;
	TL0 = 0x9C;		//���ö�ʱ��ֵ
	TH0 = 0xFF;		//���ö�ʱ��ֵ
	Count++;
	Count%=100;
	T0counter++;
	
	if(Count<Compare)
	{
		Motor=1;
	}
	else
	{
		Motor=0;
	}
	
}