#include <stc15f2k60s2.h>
#include "intrins.h"

#define somenop {_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();}
unsigned char tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf};
unsigned char buff[]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

sbit TX=P1^0;
sbit RX=P1^1;
bit flag;            
unsigned int t,distance;
void close()
{
	P2=(P2&0x1f)|0xa0;
	P0=0;
	P2&=0x1f;
	P2=(P2&0x1f)|0x80;
	P0=0xff;
	P2&=0x1f;
}

void delay(unsigned int ms)
{
	unsigned int i,j;
	for(i=ms;i>0;i--)
	for(j=845;j>0;j--);
}
void display()
{
	 unsigned char index;
	 for(index=0;index<8;index++)
	 {
		P2=(P2&0x1f)|0xe0;
		P0=0xff;
		P2&=0x1f;

		P2=(P2&0x1f)|0xc0;
		P0=1<<index;
		P2&=0x1f;

		P2=(P2&0x1f)|0xe0;
		P0=buff[index];
		P2&=0x1f;

		delay(1);
	 }
//	    P2=(P2&0x1f)|0xe0;
//		P0=0xff;
//		P2&=0x1f;
}
void Timer0Init(void)		//5ms��ʱ@11.0592MHz
{
	AUXR |= 0x80;		
	TMOD &= 0xF0;		
	TL0 = 0x00;		
	TH0 = 0x28;		
	TF0 = 0;		
	TR0 = 1;		
}

void Timer1Init(void)		//5ms��ʱ@11.0592MHz ������Ϊ��������ʱ
{
	AUXR |= 0x40;		
	TMOD &= 0x0F;		
	TL1 = 0;		
	TH1 = 0;		
	TF1 = 0;		
	//TR1 = 1;		
}
void sendwave()
{
	unsigned char i=8;
	do
	{
	   TX=1;
	   somenop;somenop;somenop;somenop;somenop;somenop;somenop;somenop;somenop;somenop;
	   TX=0;
	   somenop;somenop;somenop;somenop;somenop;somenop;somenop;somenop;somenop;somenop;

	}while(i--);
}
void main()
{
	close();
	Timer0Init();
	Timer1Init();
	EA=1;
	ET0=1;
	while(1)
	{
	   if(flag==1)  //200ms����һ��
	   {
		   sendwave();
		   TR1=1;
		   while((RX==1)&&(TF1==0));
		   TR1=0;
		   if(TF1==1)
		   {
			  distance=999;
			  TF1=0;

		   }
		   else
		   {
			   t=(TH1<<8)|TL1;
			   distance=t*0.017;
			   distance/=12;

		   }
		   TH1=0;
		   TL1=0;
		   flag=0;
	   }
	   buff[0]=tab[distance/100];
	   buff[1]=tab[distance%100/10];
	   buff[2]=tab[distance%10];
	   display();
	}

}




void time0() interrupt 1
{
	static unsigned char m5;
	m5++;
	if(m5==40)
	{
	   flag=1;
	   m5=0;
	}
}
