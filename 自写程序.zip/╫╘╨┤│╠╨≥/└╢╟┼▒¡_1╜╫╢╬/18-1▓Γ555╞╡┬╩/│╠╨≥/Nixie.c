#include <STC15F2K60S2.H>

  unsigned char Buf[]={11,20,20,20,20,20,20,20,20};
	unsigned char LocationTable[]={0X00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
	//0 1 2 3 4 5 6 7 8 9  0.(10) 1. 2. 3. 4. 5. 6. 7. 8. 9. ��(20) -(21)
	unsigned char NumberTable[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90,0XC0&0x7F,0XF9&0x7F,0XA4&0x7F,0XB0&0x7F,0X99&0x7F,0X92&0x7F,
	0X82&0x7F,0XF8&0x7F,0X80&0x7F,0X90&0x7F,0xff,0xbf};
	
	void SetBuf(unsigned char Location,Number)
	{
		Buf[Location]=Number;
	}
	
	void Nixie_Scan(unsigned char Location,Number)
	{
		P2=0xC0;
		P0=LocationTable[Location];
		
		P2=0xE0;
		P0=NumberTable[Number];
		
		P2=0x00;
		
	}
	
	void Nixie_Loop()
	{
		static unsigned char i=1;
		Nixie_Scan(i,Buf[i]);
		i++;
		if(i>8)
		{
			i=1;
		}
	}