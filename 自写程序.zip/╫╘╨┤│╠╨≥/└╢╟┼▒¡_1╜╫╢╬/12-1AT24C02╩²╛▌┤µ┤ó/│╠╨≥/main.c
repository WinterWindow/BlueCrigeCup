#include<STC15F2K60S2.H>
#include "Delay.h"
#include "LCD1602.h"
#include "Key.h"
#include "AT24C02.h"
void main()
{
	unsigned char Data;
	LCD_Init();
	AT24C02_WriteByte(1,66);
	Delay(10);
	Data=AT24C02_ReadByte(1);
	LCD_ShowNum(2,1,Data,3);
	Data++;
	AT24C02_WriteByte(1,Data);
    while(1)
   {
		 
   }
}