#include<STC15F2K60S2.H>
#include "Delay.h"
#include "Timer0.h"
#include "Nixie.h"
#include "Key.h"
sbit LED=P0^0;
unsigned int Count,Compare;
unsigned char Speed,KeyNum;
void main()
{
	Timer0Init();
	Compare=5;
	P2=0x80;
	P0=0xFF;
    while(1)
   {
		 KeyNum=Key();
		 if(KeyNum==1)
		 {
			 Speed++;
			 Speed%=4;
			 if(Speed==0){Compare=0;}
			 if(Speed==1){Compare=5;}
			 if(Speed==2){Compare=50;}
			 if(Speed==3){Compare=80;}
		 }
		 Nixie(1,Speed);
   }
}
void Timer0_Routine() interrupt 1
{
	static unsigned int T0counter;
	TL0 = 0x9C;		//���ö�ʱ��ֵ
	TH0 = 0xFF;		//���ö�ʱ��ֵ
	Count++;
	Count%=100;
	T0counter++;
	P2=0x80;
	P0=0xFF;
	if(Count<Compare)
	{
		LED=0;
	}
	else
	{
		LED=1;
	}
	
}