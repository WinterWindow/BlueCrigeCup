#include<STC15F2K60S2.H>
#include "Delay.h"
sbit L1=P3^0;
sbit L2=P3^1;
sbit L3=P3^2;
sbit L4=P3^3;

sbit C1=P4^4;
sbit C2=P4^2;
sbit C3=P3^5;
sbit C4=P3^4;
unsigned char MatrixKey()
{
	unsigned char KeyNumber=0;
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L1=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);KeyNumber=1;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);KeyNumber=2;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);KeyNumber=3;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);KeyNumber=4;}
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L2=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);KeyNumber=5;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);KeyNumber=6;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);KeyNumber=7;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);KeyNumber=8;}
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L3=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);KeyNumber=9;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);KeyNumber=10;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);KeyNumber=11;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);KeyNumber=12;}
	
	L1=1;
	L2=1;
	L3=1;
	L4=1;
	
	L4=0;
	if(C1==0){Delay(20);while(C1==0);Delay(20);KeyNumber=13;}
	if(C2==0){Delay(20);while(C2==0);Delay(20);KeyNumber=14;}
	if(C3==0){Delay(20);while(C3==0);Delay(20);KeyNumber=15;}
	if(C4==0){Delay(20);while(C4==0);Delay(20);KeyNumber=16;}
	return KeyNumber;
	
}