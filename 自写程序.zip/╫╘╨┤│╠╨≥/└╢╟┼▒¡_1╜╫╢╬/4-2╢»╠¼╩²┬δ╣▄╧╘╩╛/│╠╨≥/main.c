#include<STC15F2K60S2.H>
#include<INTRINS.H>
void cls()
{
	P2=(P2&0X1F)|0XA0;//�رշ�����
	P0=0X00;
	P2=P2&0X1F;
	
	P2=(P2&0X1F)|0X80;//�ر�LED
	P0=0XFF;
	P2=P2&0X1F;
}

void delay(unsigned int xms)		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	_nop_();
	while(xms--)
	{
		i = 11;
		j = 190;
		do
		{
			while (--j);
		} while (--i);
	}
	
}
unsigned char LocationTable[9]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80};//λѡ
unsigned char NumberTable[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};//��ѡ
void Nixie(unsigned int Location,Number)
{
	P2=(P2&0X1F)|0XC0;
	P0=LocationTable[Location];
	P2=P2&0X1F;
	
	P2=(P2&0X1F)|0XE0;
	P0=NumberTable[Number];
	P2=P2&0X1F;
	delay(1);//����Ҫdelayһ��
}
void main()
{
	
	cls();
	
	while(1)//ע�� ����Ҫ��while 
	{
		Nixie(1,1);
		Nixie(2,2);
	};
}