#include<STC15F2K60S2.H>

void Close(void)
{
	P2=0xA0;
	P06=0;
	
	
	P2=0xC0;
	P0=0xFF;
	P2=0xE0;
	P0=0xFF;
	
	P2=0x80;
	P0=0xFF;
	P2=0X00;
}
