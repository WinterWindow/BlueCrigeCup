#include <STC15F2K60S2.H>
unsigned char Nixie_Buf[]={10,10,10,10,10,10,10,10,10};
unsigned char LocTable[]={0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char NumTable[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90,0xff,0xbf};
void Delay(unsigned char x)		//@12.000MHz
{
	unsigned char i, j;

	while(x--)
	{
		i = 12;
		j = 169;
		do
		{
			while (--j);
		} while (--i);		
	}

}

void SetBuf(unsigned char Loc,Num)
{
	Nixie_Buf[Loc]=Num;
}
void Nixie_Scan(unsigned char Loc,Num)
{
	P2=0xC0;
	P0=LocTable[Loc];
	P2=0xE0;
	P0=NumTable[Num];
}
void Nixie_Loop()
{
	static unsigned char i=1;
	
	Nixie_Scan(i,Nixie_Buf[i]);
	Delay(1);
	i++;
	if(i>8)
		i=1;
}