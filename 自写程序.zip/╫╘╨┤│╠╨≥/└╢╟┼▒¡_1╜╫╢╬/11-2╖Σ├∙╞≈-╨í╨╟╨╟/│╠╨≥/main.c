#include<STC15F2K60S2.H>
#include "Delay.h"
#include "Timer0.h"
sbit Buzzer=P0^6;
#define SPEED 125

unsigned int FreqTable[]=
	{0,63628,63731,63835,63928,64021,64103,64185,64260,64331,
		 64400,64463,64524,64580,64633,64684,64732,64777,64820,
		 64860,64898,64934,64968,65000,65030,65058,65085,65110,
		 65134,65157,65178,65198,65217,65235,65252,65268,65283,};
unsigned char Music[]=
{ 13,4,
	13,4,
	20,4,
	20,4,
	
	22,4,
	22,4,
	20,4+4,
	
	18,4,
	18,4,
	17,4,
	17,4,
	
	15,4,
	15,4,
	13,4+4,
	100,
};
unsigned char FreqSelect,MusicSelect;
void main()
{
		Timer0Init();
    while(1)
   {
		 if(Music[MusicSelect]!=100)
		 { 
			 FreqSelect=Music[MusicSelect];
		 MusicSelect++;
		 Delay(Music[MusicSelect]*SPEED);
		 MusicSelect++;
		 TR0=0;
		 Delay(5);
		 TR0=1;
		 }
		 else
		 {
			 TR0=0;
			 while(1);
		 }
		
   }
}
void Timer0_Routine() interrupt 1
{
	if(FreqTable[FreqSelect]!=0)
	{
			TH0=FreqTable[FreqSelect]/256;
			TL0=FreqTable[FreqSelect]%256;
			P2=P2&0x1F;
			P2=P2|0xA0;
			Buzzer=!Buzzer;
			P2=P2&0x1F;
	}
	
}