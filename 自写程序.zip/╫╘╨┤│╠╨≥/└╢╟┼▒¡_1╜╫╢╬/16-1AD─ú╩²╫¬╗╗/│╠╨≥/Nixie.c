#include<STC15F2K60S2.H>
#include "Delay.h"
unsigned char Buf[]={10,10,10,10,10,10,10,10,10,10,10};
// �� 1 2 3 4 5 6 7 8
	unsigned char LocationTable[9]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80};//λѡ
	//0 1 2 3 4 5 6 7 8 9 �� -
  unsigned char NumberTable[12]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90,0xff,0xbf};//��ѡ

void Nixie_SetBuf(unsigned char Location,Number)
{
	Buf[Location]=Number;
}
void Nixie_Scan(unsigned char Location,Number)
{
	
	P2=0XC0;
	P0=LocationTable[Location];
	
	P2=0XE0;
	P0=NumberTable[Number];
	Delay(1);
	P2=0X00;
}

void Nixie_Loop(void){
	static unsigned char i=1;
	Nixie_Scan(i,Buf[i]);
	i++;
	if(i>8)
	{
		i=1;
	}
}