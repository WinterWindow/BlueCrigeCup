#include<STC15F2K60S2.H>
#include "Close.h"
#include "Delay.h"
#include "I2C.h"
#include "LCD1602.h"
#include "PCF8591.h"
#include "Nixie.h"
unsigned char Temp1,Temp2;

void main()
{
//	LCD_Init();
	while(1)
	{
		Temp1=PCF8591_AD(0x03);
//		LCD_ShowNum(1,1,Temp1,3);
		
		Temp2=PCF8591_AD(0x01);
//		LCD_ShowNum(2,1,Temp2,3);
		Nixie_Scan(1,Temp1/100);
		Nixie_Scan(2,Temp1/10%10);
		Nixie_Scan(3,Temp1%100%10);
		
		
		Nixie_Scan(5,Temp2/100);
		Nixie_Scan(6,Temp2/10%10);
		Nixie_Scan(7,Temp2%100%10);
	}
}