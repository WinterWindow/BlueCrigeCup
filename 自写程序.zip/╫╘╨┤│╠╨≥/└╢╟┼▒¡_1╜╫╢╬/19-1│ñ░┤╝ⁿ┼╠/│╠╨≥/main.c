#include <STC15F2K60S2.H>
#include "Nixie.h"
#include "Timer0.h"
#include "UART.h"
#include "Delay.h"
#include "stdio.h"
unsigned char Byte[12],uart_num;
unsigned long ulms=0,ult=0;
unsigned char KeyNumber;
unsigned char Key();
unsigned char GetKeyState();
void Key_Loop();
void main()
{
	Timer0Init();
	UartInit();
	sprintf(Byte,"#%02u,%02u\r\n",(unsigned int)2,(unsigned int)1);
	UART_SendByte(Byte);
	while(1)
	{
		Nixie_Loop();
//		Delay(1000);
		
		
//		Key_Loop();
//		if(KeyNumber)
//		{
//			SetBuf(KeyNumber/10,1);
//			SetBuf(KeyNumber%10,2);
//		}
		
	}
}




unsigned char GetKeyState()
{
	unsigned char State=0;
	if(P30==0){State=7;};
	if(P31==0){State=6;};
	if(P32==0){State=5;};
	if(P33==0){State=4;};
	return State;
}
void Key_Loop()
{
	static unsigned char NowState,LastState;
	LastState=NowState;
	NowState=GetKeyState();
	if(LastState==0&&(NowState!=0))
	{
		ult=ulms;
	}
	if(NowState==0)
	{
		if(ulms-ult<1000)
		{
			if(LastState==7){KeyNumber=7;};
			if(LastState==6){KeyNumber=6;};
			if(LastState==5){KeyNumber=5;};
			if(LastState==4){KeyNumber=4;};
		}
		else
		{
			if(LastState==7){KeyNumber=27;};
			if(LastState==6){KeyNumber=26;};
			if(LastState==5){KeyNumber=25;};
			if(LastState==4){KeyNumber=24;};
		}
	}

}

void Timer0_R() interrupt 1
{

	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	ulms++;
}
void Uart_Proc(void)
{
	if(uart_num>0)
	{
		if(Byte[uart_num-1]==0x0a)
		{
//			if(Byte[0]=="S"&&Byte[1]=="T"&&Byte[2]==0xd)
//			{
//				sprintf(Byte,"#%02u,%02u\r\n",(unsigned int)2,(unsigned int)1);
//			}
//			uart_num=0;
		}
		else
			if(uart_num==6)
			{
				UART_SendByte("ERROR\r\n");
				uart_num=0;
			}
	}
}
void uart_0(void) interrupt 4
{
	if(RI)
	{
		Byte[uart_num++]=SBUF;
		RI=0;
	}
}