#include <STC15F2K60S2.H>
unsigned char Nixie_Buf[]={10,1,2,3,4,5,6,7,8};
unsigned char NumberTable[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90,0xff,0xbf};
unsigned char LocationTable[]={0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

void SetBuf(unsigned char Number,Location)
{
	Nixie_Buf[Location]=Number;
}
void Nixie_Scan(unsigned char Number,Location)
{
	

	P0=0xff;
	
	P2=0xC0;
	P0=LocationTable[Location];
	
	
	P2=0xE0;
	P0=NumberTable[Number];
	
	
}
void Nixie_Loop()
{
	static unsigned char i=1;
	Nixie_Scan(Nixie_Buf[i],i);
	i++;
	if(i>8)
	{
		i=1;
	}
}