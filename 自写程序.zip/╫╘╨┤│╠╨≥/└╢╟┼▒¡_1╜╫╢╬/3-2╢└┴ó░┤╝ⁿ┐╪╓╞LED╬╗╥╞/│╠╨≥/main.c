#include<STC15F2K60S2.H>
#include<intrins.h>
void cls_buzz()
{
	P2=(P2&0X1F)|0XA0;
	P0=0X00;
	P2=P2&0X1F;
}

void delay(unsigned int xms)	//@11.0592MHz
{
	unsigned char i, j;
	while(xms)
	{
			_nop_();
	_nop_();
	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
	xms--;
	}

}
sbit S4 = P3^3;
sbit S5 = P3^2;
unsigned int i=0;
void main()
{
	cls_buzz();
	
	P2=(P2&0X1F)|0X80;
	P0=0XFE;
	P2=0X1F;
	
	while(1)
	{
			
		if(S4==0)
		{
			
			
			  delay(20);
			while(S4==0);
				delay(20);
			
				i++;
			if(i==8)
				i=0;
			
			P2=(P2&0X1F)|0X80;
			P0=~(0x01<<i);//0000 0001
			P2=0X1F;
			
			
		}
		if(S5==0)
		{
			
			  delay(20);
			while(S5==0);
				delay(20);
			
			i--;
			if(i==-1)
				i=7;
			
			P2=(P2&0X1F)|0X80;
			P0=~(0x01<<i);//0000 0001
			P2=0X1F;
				
		}
	}
}
