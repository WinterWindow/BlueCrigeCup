#include<STC15F2K60S2.H>
sbit LED=P0^0;
void Delay(unsigned int t)
{
	while(t--);
}
unsigned int Time,i;
void main()
{
		P2=0x80;
		P0=0xFF;
    while(1)
   {
		 P2=0x80;
		  for(Time=0;Time<100;Time++)
		 {
			 for(i=0;i<100;i++)
			 {
				LED=0;
				Delay(100-Time);
				LED=1;
				Delay(Time);
			 }
		 }
		 for(Time=0;Time<100;Time++)
		 {
			 for(i=0;i<100;i++)
			 {
				LED=0;
				Delay(Time);
				LED=1;
				Delay(100-Time);
			 }
		 }
		 
   }
}