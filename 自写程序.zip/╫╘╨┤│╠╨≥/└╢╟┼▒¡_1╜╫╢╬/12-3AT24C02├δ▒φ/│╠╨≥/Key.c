#include<STC15F2K60S2.H>
#include "Delay.h"
unsigned char Key_KeyNumber;

unsigned char Key(void)
{
	unsigned char Temp;
	Temp=Key_KeyNumber;
	Key_KeyNumber=0;
	return Temp;
}
/**
   *  @brief  ��ȡ������������
   *  @param	��
   *  @retval	���°����ļ��룬��Χ��0~4���ް�������ʱ����ֵΪ0
   */
unsigned char Key_GetState()
{
	unsigned char KeyNumber=0;
	if(P30==0){KeyNumber=1;}
	if(P31==0){KeyNumber=2;}
	if(P32==0){KeyNumber=3;}
	if(P33==0){KeyNumber=4;}
	
	return KeyNumber;
}
void Key_Loop(void)
{
	static unsigned char NowState,LastState;
	LastState=NowState;
	NowState=Key_GetState();
	if(LastState==0 && NowState==1)
	{
		Key_KeyNumber=1;
	}
	if(LastState==2 && NowState==0)
	{
		Key_KeyNumber=2;
	}
	if(LastState==3 && NowState==0)
	{
		Key_KeyNumber=3;
	}
	if(LastState==4 && NowState==0)
	{
		Key_KeyNumber=4;
	}
}