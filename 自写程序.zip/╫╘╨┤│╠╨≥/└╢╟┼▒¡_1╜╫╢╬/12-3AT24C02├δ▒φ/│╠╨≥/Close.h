#ifndef __Close_H__
#define __Close_H__

void Close(void);
#endif