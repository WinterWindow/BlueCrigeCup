#include<STC15F2K60S2.H>
#include "AT24C02.h"
#include "Key.h"
#include "DS18B20.h"
#include "LCD1602.h"
#include "Delay.h"
#include "Timer0.h"
#include "Close.h"
float T,Tshow;
char TH,TL;

unsigned char KeyNum;
void main()
{
	Close();
	DS18B20_ConvertT();
	Delay(1000);
	LCD_Init();
	Timer0Init();
	TH=AT24C02_ReadByte(0);
	TL=AT24C02_ReadByte(1);
	if(TH>155||TL<-55||TH<TL)
	{
		TH=10;
		TL=0;
	}
	LCD_ShowString(1,1,"T:");
	LCD_ShowChar(1,7,'.');
	LCD_ShowString(2,1,"TH:");
	LCD_ShowString(2,9,"TL:");
    while(1)
   {
		 Close();
		 /*�¶��жϼ���ʾ*/
		 DS18B20_ConvertT();
		 T=DS18B20_ReadT();
		 if(T<0)
		 {
			 LCD_ShowChar(1,3,'-');
			 Tshow=-T;
		 }
		 else
		 {
			 LCD_ShowChar(1,3,'+');
			 Tshow=T;
		 }
		 LCD_ShowNum(1,4,Tshow,3);
		 
		 LCD_ShowNum(1,8,(unsigned long)(Tshow*100)%100,2);
		 /*��ֵ�жϼ���ʾ*/
		 LCD_ShowSignedNum(2,4,TH,3);
		 LCD_ShowSignedNum(2,12,TL,3);
		 
		 KeyNum=Key();
		 if(KeyNum)
		 {
			 if(KeyNum==1)
			 {
				 TH++;
				 if(TH>125)TH=125;
			 }
				if(KeyNum==2)
			 {
				 TH--;
				 if(TH<=TL)TH++;
			 }
				if(KeyNum==3)
			 {
				 TL++;
				 if(TH<=TL)TL--;
			 }
				if(KeyNum==4)
			 {
				 TL--;
				 if(TL<-55)TL=-55;
			 }
	   }
		 if(T>TH)
		 {
			 LCD_ShowString(1,11,"OV:H");
		 }
		 else if(T<TL)
		 {
			 LCD_ShowString(1,11,"OV:L");
		 }
		 else
		 {
			 LCD_ShowString(1,11,"    ");
		 }
		 AT24C02_WriteByte(0,TH);
		 Delay(5);
		 AT24C02_WriteByte(1,TL);
		 Delay(5);
   }
}
void Timer0_Routine() interrupt 1
{
	static unsigned int T0Count1;//����ȫ�ֱ��� �Ǿֲ���̬���� �˳�֮���ǻ�ռ�ݿռ� �����ͷ� ������һ�ε�ֵ
	TH0=0XFC;//65535/256
	TL0=0X18;//65535%256+1
	T0Count1++;
	if(T0Count1>=20)
	{
			T0Count1=0;
			Key_Loop();
	}
}