#include<STC15F2K60S2.H>
#include "LCD1602.h"
void main()
{
	LCD_ShowString(2,1,"123");
    while(1)
   {

   }
}