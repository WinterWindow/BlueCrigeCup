#include<STC15F2K60S2.H>
void cls_buzz(void)
{
	P2 = (P2&0x1F|0xA0);
	P0 = 0x00;
	P2 &= 0x1F;
}

sbit S4  = P3^3;
void main()
{
	cls_buzz();
	while(1)
	{
		if(S4==0)
		{
			P2=(P2&0x1F)|0x80;
			P0=0X00;
			P2=P2&0x1F;
		}
		else
		{
			P2=(P2&0x1F)|0x80;
			P0=0XFF;
			P2=P2&0x1F;
		}
	}
	
}