#include<STC15F2K60S2.H>
#include "LCD1602.h"
void main()
{
	LCD_Init();
	LCD_ShowChar(1,1,'A');
	while(1)
	{
		
	}
	
}