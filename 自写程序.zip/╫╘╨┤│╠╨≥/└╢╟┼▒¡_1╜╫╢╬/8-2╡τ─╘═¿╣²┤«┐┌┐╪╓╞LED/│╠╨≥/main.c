#include<STC15F2K60S2.H>
#include "UART.h"
#include "Delay.h"
void main()
{
		UART_Init();
    while(1)
   {

   }
}
void UART1_Routine() interrupt 4
{
		if(RI==1)
		{
			P2 = 0x80;
	  	P0=SBUF;
			//UART_SendByte(SBUF);
			RI=0;
		}
}