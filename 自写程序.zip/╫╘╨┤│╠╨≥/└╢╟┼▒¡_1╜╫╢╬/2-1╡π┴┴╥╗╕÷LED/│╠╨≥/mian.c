#include<STC15F2K60S2.H>


void main(void){
	P2=0XA0;P0=0X00;
	P2=0X80;P0=0XFF;
	P02=0;
	while(1);
}