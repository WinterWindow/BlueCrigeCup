#include<STC15F2K60S2.H>
#include "Delay.h"
#include "UART.h"
//2400bps@12.000MHz
unsigned char Sec;

void main()
{
	UART_Init();
	
    while(1)
   {
		  Sec++;
			UART_SendByte(0x11);
		  Delay(1000);
   }
}