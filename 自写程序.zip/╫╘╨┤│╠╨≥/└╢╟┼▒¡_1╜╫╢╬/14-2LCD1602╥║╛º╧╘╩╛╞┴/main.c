#include<STC15F2K60S2.H>
#include "LCD1602.h"
#include "Delay.h"

void main()
{
	LCD_Init();
//	LCD_ShowChar(2,6,0x7E);
//	LCD_ShowString(1,3,"ABC");
//	LCD_ShowNum(1,7,666,3);
//	LCD_ShowSignedNum(1,1,-678,3);
//	LCD_ShowBinNum(1,1,0x11,8);
//	LCD_ShowChar(2,1,0xDF);
//	LCD_ShowChar(2,2,'C');
		LCD_ShowString(2,16,"Welcome to China");
	while(1)
	{
		Delay(500);
		LCD_WriteCommand(0x18);
	}
	
}