#include <STC15F2K60S2.H>
#include "Timer.h"
#include "Nixie.h"
unsigned int fan,zheng,fan_now,zheng_now;
bit flag_t=0;
unsigned long Time,frq;
void main()
{
	Timer0Init();
	Timer1Init();
	while(1)
	{
		Set_Buf(1,frq/1000%10);
		Set_Buf(2,frq/100%10);
		Set_Buf(3,frq/10%10);
		Set_Buf(4,frq%10);
		Nixie_Loop();
	}
}
void Timer0_R() interrupt 1
{
	static unsigned int count;
	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	count++;
	if(count>=969)
	{
		TR1 = 1;
		ET1=1;
		if(count>=999)
		{
			TR1 = 0;
			ET1=0;
			count=0;
			Time=5*(fan_now+zheng_now);
			frq=1000000/Time;
		}
	}
}
void Timer1_R() interrupt 3
{
	TL1 = 0xFB;		//���ö�ʱ��ֵ
	TH1 = 0xFF;		//���ö�ʱ��ֵ
	if(P34==0)
	{
		fan++;
		if(flag_t==0)
		{
			zheng_now=zheng;
			zheng=0;
			flag_t=1;
		}
	}
	else if(P34==1)
	{
		zheng++;
		if(flag_t==1)
		{
			fan_now=fan;
			fan=0;
			flag_t=0;
		}
	}
}