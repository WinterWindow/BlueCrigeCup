#ifndef __NIXIE_H__
#define __NIXIE_H__
void Delay(unsigned char ms);
void Set_Buf(unsigned char Location,Number);
void Nixie_Loop();
#endif