#ifndef __TIMER_H__
#define __TIMER_H__
void Timer0Init(void);
void Timer1Init(void);
#endif