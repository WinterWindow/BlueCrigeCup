#ifndef __ULTRASONIC_H__
#define __ULTRASONIC_H__
void Timer0Init(void);
void Timer1Init(void);
unsigned char Wave_Reac();
#endif