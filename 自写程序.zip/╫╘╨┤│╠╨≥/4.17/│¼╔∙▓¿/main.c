#include <STC15F2K60S2.H>
#include "ultrasonic.h"
#include "Nixie.h"
bit flag_t=0;
unsigned char Length;
void main()
{
	Timer0Init();
	Timer1Init();
	while(1)
	{
		if(flag_t)Length=Wave_Reac();
		Set_Buf(1,Length/100%10);
		Set_Buf(2,Length/10%10);
		Set_Buf(3,Length%10);
		Nixie_Loop();
	}
}

void Timer0_R() interrupt 1
{
	static unsigned char count0;
	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	count0++;
	if(count0<200)flag_t=0;
	else{flag_t=1;count0=0;}
}