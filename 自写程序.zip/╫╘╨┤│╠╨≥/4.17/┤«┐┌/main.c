#include <STC15F2K60S2.H>
#include "stdio.h"
#include "UART.h"
unsigned char Uart_Buf[12],num=0;
unsigned char A=10;
void SendString(unsigned char *p);
void Uart_Loop();
void main()
{
	UartInit();
	while(1)
	{
		Uart_Loop();
	}
}
void SendString(unsigned char *p)
{
	while(*p!='\0')
	{
		SBUF=*p;
		while(!TI);
		TI=0;
		p++;
	}
}
void Uart_Loop()
{
	if(num>0)
	{
		if(Uart_Buf[num-1]==0x0a)
		{
			if((Uart_Buf[0]=='A')&&(Uart_Buf[1]=='B')&&(Uart_Buf[2]=='C')&&(Uart_Buf[3]==0x0d))
			{
				sprintf(Uart_Buf,"$%02u\r\n",(unsigned int)A);
				SendString(Uart_Buf);
			}
			else
			{
				SendString("ERROR\r\n");
			}
			num=0;
		}
		else
			if(num>6)
			{
				SendString("ERROR\r\n");
			}
	}
}
void Uart_R() interrupt 4
{
	if(RI)
	{
		Uart_Buf[num++]=SBUF;
		RI=0;
	}
}