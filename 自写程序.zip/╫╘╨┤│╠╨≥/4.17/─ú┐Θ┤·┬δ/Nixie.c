#include <STC15F2K60S2.H>
unsigned char Nixie_Buf[9]={10,10,10,10,10,10,10,10,10};
unsigned char NumberTable[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
unsigned char LocationTable[9]={0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
void Delay(unsigned char ms)		//@12.000MHz
{
	unsigned char i, j;

	while(ms--)
	{
		i = 12;
		j = 169;
		do
		{
			while (--j);
		} while (--i);		
	}

}

void SetBuf(unsigned char location,number)
{
	Nixie_Buf[location]=number;
}
void Nixie_Scan(unsigned char location,number)
{
	P2=0xC0;
	P0=LocationTable[location];
	P2=0xE0;
	P0=NumberTable[number];
}
void Nixie_Loop()
{
	static unsigned char i=1;
	Nixie_Scan(i,Nixie_Buf[i]);
	Delay(1);
	i++;
	if(i>8)i=1;
}