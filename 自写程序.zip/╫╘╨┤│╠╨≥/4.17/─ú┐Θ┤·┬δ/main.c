#include <STC15F2K60S2.H>
#include "Nixie.h"
#include "AT24C02.h"
unsigned char A;
void main()
{
	AT24C02_WriteByte(1,10);
	Delay(10);
	while(1)
	{
		A=AT24C02_ReadByte(1);
		SetBuf(1,A/10%10);
		SetBuf(2,A%10);
		Nixie_Loop();
	}
}