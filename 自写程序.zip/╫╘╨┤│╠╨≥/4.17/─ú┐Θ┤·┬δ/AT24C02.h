#ifndef __AT24C02_H
#define __AT24C02_H
void AT24C02_WriteByte(unsigned char Address,Number);
unsigned char AT24C02_ReadByte(unsigned char Address);
void PCF8591_WriteByte(unsigned char Number);
unsigned char PCF8591_ReadByte(unsigned char Address);
#endif