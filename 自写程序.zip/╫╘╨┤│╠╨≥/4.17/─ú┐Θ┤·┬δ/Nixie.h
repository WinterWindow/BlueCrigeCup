#ifndef __NIXIE_H
#define __NIXIE_H
void Delay(unsigned char ms);
void SetBuf(unsigned char location,number);
void Nixie_Loop();
#endif