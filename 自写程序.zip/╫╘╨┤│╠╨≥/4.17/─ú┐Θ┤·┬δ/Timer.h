#ifndef __TIMER_H
#define __TIMER_H
void Timer0Init(void);
#endif