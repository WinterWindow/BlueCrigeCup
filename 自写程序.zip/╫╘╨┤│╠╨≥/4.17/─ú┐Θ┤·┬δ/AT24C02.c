#include <STC15F2K60S2.H>
#include "iic.h"

void AT24C02_WriteByte(unsigned char Address,Number)
{
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_WaitAck();
	IIC_SendByte(Address);
	IIC_WaitAck();
	IIC_SendByte(Number);
	IIC_WaitAck();
	IIC_Stop();
}
unsigned char AT24C02_ReadByte(unsigned char Address)
{
	unsigned char Number;
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_WaitAck();
	IIC_SendByte(Address);
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0xA1);
	IIC_WaitAck();
	Number=IIC_RecByte();
	IIC_SendAck(1);	
	IIC_Stop();
	return Number;
}
void PCF8591_WriteByte(unsigned char Number)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x40);
	IIC_WaitAck();
	IIC_SendByte(Number);
	IIC_WaitAck();
	IIC_Stop();
}
unsigned char PCF8591_ReadByte(unsigned char Address)
{
	unsigned char Number;
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(Address);
	IIC_WaitAck();
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	Number=IIC_RecByte();
	IIC_SendAck(1);	
	IIC_Stop();
	return Number;
}