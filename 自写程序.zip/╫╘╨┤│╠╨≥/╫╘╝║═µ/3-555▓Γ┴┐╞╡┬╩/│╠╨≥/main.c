#include <STC15F2K60S2.H>
#include "Timer.h"
#include "Nixie.h"
bit t_flag=0,t1_flag=0;

unsigned int fan=0,zheng=0,fan_now=0,zheng_now=0;
unsigned long frq,Time;
void main()
{
	Timer0Init();
	Timer1Init();
	while(1)
	{
		SetBuf(1,frq/1000%10);
		SetBuf(2,frq/100%10);
		SetBuf(3,frq/10%10);
		SetBuf(4,frq%10);
		
		Nixie_Loop();
	}
}

void Timer0_R(void) interrupt 1
{
	static unsigned int count0;
	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	
	count0++;
	if(count0>=969)
	{
		ET1=1;
		TR1 = 1;
		if(count0>=999)
		{
			count0=0;
			ET1=0;
			TR1 = 0;
			
			Time=5*(fan_now+zheng_now);
			frq=1000000/Time;
		}
	}
}
void Timer1_R() interrupt 3
{
	TL1 = 0xFB;		//���ö�ʱ��ֵ
	TH1 = 0xFF;		//���ö�ʱ��ֵ
	if(P34==0)
	{
		fan++;
		if(t_flag==0)
		{
			t_flag=1;
			zheng_now=zheng;
			zheng=0;
		}
	}
	else if(P34==1)
	{
		zheng++;
		if(t_flag==1)
		{
			t_flag=0;
			fan_now=fan;
			fan=0;
		}
	}
}