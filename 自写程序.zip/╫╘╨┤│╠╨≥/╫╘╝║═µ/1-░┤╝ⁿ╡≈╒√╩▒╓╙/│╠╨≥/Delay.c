#include <STC15F2K60S2.H>
void Delay(unsigned char ms)		//@12.000MHz
{
	unsigned char i, j;
	while(ms--)
	{
		i = 12;
		j = 169;
		do
		{
			while (--j);
		} while (--i);
	}
}