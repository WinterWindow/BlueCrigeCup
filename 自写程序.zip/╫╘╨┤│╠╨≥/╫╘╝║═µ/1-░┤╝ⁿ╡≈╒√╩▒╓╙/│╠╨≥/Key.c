#include <STC15F2K60S2.H>

unsigned char KeyNumber;
unsigned char Key()
{
	unsigned char Temp;
	Temp=KeyNumber;
	KeyNumber=0;
	return Temp;
}	
unsigned char GetState()
{
	unsigned char KN=0;
	if(P30==0)KN=7;
	if(P31==0)KN=6;
	if(P32==0)KN=5;
	if(P33==0)KN=4;
	return KN;
}

void Key_Loop()
{
	static unsigned char Now,Last;
	Last=Now;
	Now=GetState();
	if(Last==7&&Now==0)KeyNumber=7;
	if(Last==6&&Now==0)KeyNumber=6;
	if(Last==5&&Now==0)KeyNumber=5;
	if(Last==4&&Now==0)KeyNumber=4;
}