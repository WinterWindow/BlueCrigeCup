#ifndef __AT24C02_H__
#define __AT24C02_H__
void AT24C02_WriteByte(unsigned char Address,Byte);
unsigned char AT24C02_ReadByte(unsigned char Address);
#endif