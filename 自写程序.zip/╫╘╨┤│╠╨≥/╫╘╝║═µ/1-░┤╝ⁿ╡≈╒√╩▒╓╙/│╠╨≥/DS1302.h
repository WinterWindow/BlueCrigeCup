#ifndef __DS1302_H__
#define __DS1302_H__
extern unsigned char DS1302_Time[3];
void DS1302_Init();
void SetTime();
void ReadTime();
#endif