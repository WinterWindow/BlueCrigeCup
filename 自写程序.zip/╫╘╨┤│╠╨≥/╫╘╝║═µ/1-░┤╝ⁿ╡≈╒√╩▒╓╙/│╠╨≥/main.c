#include <STC15F2K60S2.H>
#include "Nixie.h"
#include "Delay.h"
#include "Timer0.h"
#include "Key.h"
#include "DS1302.h"
#include "AT24C02.h"
unsigned char KN;
 char h,m,s;
bit Mode=0;//0:Ĭ�ϵ���ʾʱ��ģʽ 1������ʱ��ģʽ 
unsigned char ss;//Ӧ����˸��λ�� 0:
bit flagh=1,flagm=1,flags=1;//Сʱ�����ӣ����Ƿ���
unsigned char L1,L2,L3,L4,L5,L6,L7,L8;
unsigned char LED;
void main()
{
	Timer0Init();
	DS1302_Init();
	
	DS1302_Time[0]=AT24C02_ReadByte(1);
	DS1302_Time[1]=AT24C02_ReadByte(2);
	DS1302_Time[2]=AT24C02_ReadByte(3);
	SetTime();
	SetBuf(3,11);
	SetBuf(6,11);
	P2=0x80;
	P0=0xff;
	while(1)
	{
		if(Mode==0)
		{
			ss=0;flagh=1;flagm=1;flags=1;
			ReadTime();
			h=DS1302_Time[0];
			m=DS1302_Time[1];
			s=DS1302_Time[2];
		}
		if(Mode==1)
		{
			DS1302_Time[0]=h;
			DS1302_Time[1]=m;
			DS1302_Time[2]=s;
			
		}
		KN=Key();
		if(KN)
		{
			if(KN==7)
			{
				if(Mode==0){ss=1;}//����Ǵ�Ĭ��λ�õ�������ʱ��ģʽ����˸��λ����Сʱ
				if(Mode==1)
					{
						SetTime();
						AT24C02_WriteByte(1,DS1302_Time[0]);
						Delay(5);
						AT24C02_WriteByte(2,DS1302_Time[1]);
						Delay(5);
						AT24C02_WriteByte(3,DS1302_Time[2]);
						Delay(5);
					}
				Mode=!Mode;
			}
			if(Mode==1&&KN==6)
			{
				ss++;
				if(ss>3)ss=1;
				flagh=1;flagm=1;flags=1;
			}
			if(Mode==1&&KN==5)
			{
				switch(ss)
				{
					case 1:
						h++;
					if(h>=24)h=0;
						break;
					case 2:
						m++;
					if(m>=60)m=0;
						break;
					case 3:
						s++;
					if(s>=60)s=0;
						break;
					default:
						break;
				}
					
			}
			if(Mode==1&&KN==4)
			{
				switch(ss)
				{
					case 1:
						h--;
					if(h<=0)h=23;
						break;
					case 2:
						m--;
					if(m<=0)m=59;
						break;
					case 3:
						s--;
					if(s<=0)s=59;
						break;
					default:
						break;
				}
					
			}
		}
		if(flagh==1)
		{
			SetBuf(1,h/10%10);
			SetBuf(2,h%10);
			L1=0;
		}
		else
		{
			SetBuf(1,10);
			SetBuf(2,10);
			L1=1;
		}
		
		if(flagm==1)
		{
		SetBuf(4,m/10%10);
		SetBuf(5,m%10);
			L2=0;
		}
		else
		{
			SetBuf(4,10);
			SetBuf(5,10);
			L2=1;
		}
		
		if(flags==1)
		{
		SetBuf(7,s/10%10);
		SetBuf(8,s%10);
			L3=0;
		}
		else
		{
			SetBuf(7,10);
			SetBuf(8,10);
			L3=1;
		}
		P2=0x80;
		LED=L1|(L2<<1)|(L3<<2)|(L4<<3)|(L5<<4)|(L6<<5)|(L7<<6)|(L8<<7);
		P0=~LED;
		Nixie_Loop();
	}
	
}

void Timer0_R() interrupt 1
{
	static unsigned char count0;
	static unsigned int counth,countm,counts;
	TL0 = 0x18;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	count0++;
	if(count0>20){count0=0;Key_Loop();}
	if(ss==1)
	{
		counth++;
		if(counth<=200){flagh=1;}
		else if(counth<=400){flagh=0;}
		else counth=0;
	}
	else
		counth=0;
	if(ss==2)
	{
		countm++;
		if(countm<=200){flagm=1;}
		else if(countm<=400){flagm=0;}
		else countm=0;
	}
	else
		countm=0;
	if(ss==3)
	{
		counts++;
		if(counts<=200){flags=1;}
		else if(counts<=400){flags=0;}
		else counts=0;
	}
	else
		counts=0;
	
}