#ifndef __ULTRASONIC_H__
#define __ULTRASONIC_H__
void Timer1Init(void);
unsigned char Wave_Recv(void);
#endif