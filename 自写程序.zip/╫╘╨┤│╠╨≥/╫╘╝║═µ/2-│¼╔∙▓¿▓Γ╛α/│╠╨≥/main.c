#include <STC15F2K60S2.H>
#include "ultrasonic.h"
#include "Nixie.h"
#include "LCD1602.h"
#include "Delay.h"
#include "Timer0.h"
unsigned int Length;
bit flag1=0;
void main()
{
	Timer0Init();
	Timer1Init();
	LCD_Init();
	while(1)
	{
		if(flag1)Length=Wave_Recv();
		SetBuf(1,Length/10%10);
		SetBuf(2,Length%10);
		
		//LCD_ShowNum(1,1,Length,5);
	}
}

void Timer0_R() interrupt 1
{
	static unsigned char count0;
	TL0 = 0x18;			//���ö�ʱ��ֵ
	TH0 = 0xFC;			//���ö�ʱ��ֵ
	count0++;
	if(count0<=200)
	{
		flag1=0;
	}
	else
	{
		count0=0;
		flag1=1;
	}
	Nixie_Loop();
}