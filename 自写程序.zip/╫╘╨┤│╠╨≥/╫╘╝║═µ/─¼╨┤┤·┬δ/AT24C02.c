#include <STC15F2K60S2.H>
#include "iic.h"
//0xA0
void AT24C02_Write(unsigned char Address,Data)
{
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_WaitAck();
	IIC_SendByte(Address);
	IIC_WaitAck();
	IIC_SendByte(Data);
	IIC_WaitAck();
	IIC_Stop();
}

unsigned char AT24C02_Read(unsigned char Address)
{
	unsigned char Data;
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_WaitAck();
	IIC_SendByte(Address);
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0xA1);
	IIC_WaitAck();
	Data=IIC_RecByte();
	IIC_RecByte();
	IIC_Stop();
	return Data;
}
