#include <STC15F2K60S2.H>
#include "Nixie.h"
#include "Timer.h"
#include "DS18B20.h"
bit flag1=0;
float T;
void main()
{
	Timer0Init();
	Convert_T();
	while(1)
	{
		Convert_T();
		T=Read_T();
		Set_Buf(1,(unsigned char)(T)/10%10);
		Set_Buf(2,(unsigned char)(T)%10);
		Set_Buf(3,(unsigned char)(T*10)%10);
		Set_Buf(4,(unsigned char)(T*100)%10);
		
	}
}

void Timer0_R() interrupt 1
{
	static unsigned int count0;
	static unsigned char count1=0;

	count0++;
	count1++;
	
	if(count0>200)
	{
		count0=0;
		flag1=1;
	}
	else
	{
		flag1=0;
	}
	Nixie_Loop();
	
}
