#ifndef __PCF8591_H__
#define __PCF8591_H__
unsigned char PCF8591_Read(unsigned char Address);
void PCF8591_Write(unsigned char Data);
#endif