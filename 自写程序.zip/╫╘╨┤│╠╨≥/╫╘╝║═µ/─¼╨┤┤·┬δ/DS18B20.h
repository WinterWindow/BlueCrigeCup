#ifndef __DS18B20_H__
#define __DS18B20_H__
void Convert_T();
float Read_T();
#endif