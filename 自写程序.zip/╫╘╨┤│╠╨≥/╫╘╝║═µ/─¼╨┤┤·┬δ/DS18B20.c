#include <STC15F2K60S2.H>
#include "onewire.h"

//SKIP ROM 0xCC
//CONVERT 0x44
//READ T  0xBE

void Convert_T()
{
	init_ds18b20();
	Write_DS18B20(0xCC);
	Write_DS18B20(0x44);
}

float Read_T()
{
	unsigned char TL,TH;
	unsigned int Temp;
	float T;
	init_ds18b20();
	Write_DS18B20(0xCC);
	Write_DS18B20(0xBE);
	TL=Read_DS18B20();
	TH=Read_DS18B20();
	Temp=(TH<<8)|TL;
	T=Temp/16.0;
	return T;
}