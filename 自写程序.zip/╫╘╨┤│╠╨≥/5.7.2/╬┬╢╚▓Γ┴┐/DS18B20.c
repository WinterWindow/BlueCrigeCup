#include <STC15F2K60S2.H>
#include "onewire.h"
void Delay_OneWire1(unsigned int t)  
{
	unsigned char i;
	while(t--){
		for(i=0; i<8; i++);
	}
}
void DS18B20_ConvertT()
{
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
}
float DS18B20_ReadT()
{
	unsigned char TH,TL;
	unsigned int Temp;
	float T;
	DS18B20_ConvertT();
	
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	TL=Read_DS18B20();
	TH=Read_DS18B20();
	Temp=(TH<<8)|TL;
	T=Temp*0.0625;
	return T;
}