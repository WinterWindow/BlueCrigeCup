#include <STC15F2K60S2.H>
#include "Nixie.h"
#include "DS18B20.h"
#include "Timer.h"
bit flag_T;
int T;
unsigned char A;
void main()
{
	Timer0Init();
	while(1)
	{
		
		if(flag_T)
		{
			DS18B20_ConvertT();
			T=DS18B20_ReadT()*100;
			SetBuf(1,T%10000/1000);
			SetBuf(2,T%1000/100);
			SetBuf(3,T%100/10);
			SetBuf(4,T%10);
		}
		
	}
}
void Timer0_R() interrupt 1
{
	static unsigned char count0;
	count0++;
	Nixie_Loop();
	if(count0>200)
	{
		count0=0;
		flag_T=1;
	}
	else
	{
		flag_T=0;
	}
}