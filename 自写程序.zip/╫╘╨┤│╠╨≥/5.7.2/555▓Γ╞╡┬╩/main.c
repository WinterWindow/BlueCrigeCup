#include <STC15F2K60S2.H>
#include "Timer.h"
#include "Nixie.h"
bit flag=0;
unsigned int fan,zheng,fan_now,zheng_now;
unsigned long frq;
void main()
{
	Timer0Init();
	Timer1Init();
	while(1)
	{
		SetBuf(1,frq/1000%10);
		SetBuf(2,frq/100%10);
		SetBuf(3,frq/10%10);
		SetBuf(4,frq%10);
		Nixie_Loop();
	}
}
void Timer0_R() interrupt 1
{
	static unsigned int count0;
	count0++;
	
	if(count0>969)
	{
		ET1=1;
		TR1 = 1;
		if(count0>999)
		{
			ET1=0;
			TR1 = 0;
			count0=0;
			frq=1000000/(5*(fan_now+zheng_now));
		}
	}
}
void Time1_R() interrupt 3
{
	if(P34==0)
	{
		fan++;
		
		if(flag==0)
		{
			flag=1;
			zheng_now=zheng;
			zheng=0;
		}
	}
	else
	{
		zheng++;
		if(flag==1)
		{
			flag=0;
			fan_now=fan;
			fan=0;
		}
	}
}