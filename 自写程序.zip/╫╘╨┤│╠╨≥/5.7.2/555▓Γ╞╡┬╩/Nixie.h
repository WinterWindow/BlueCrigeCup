#ifndef __NIXIE_H__
#define __NIXIE_H__
void SetBuf(unsigned char Loc,Num);
void Nixie_Loop();
#endif