#include <STC15F2K60S2.H>
typedef unsigned char u8;
typedef unsigned int u16;
sbit A1=P1^0;
sbit B1=P1^1;
u8 code ledguan[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
u8 wei_xuan,disp[8];
u16 wave_count,time,length;

void delay(u16 i);
void Start();
void DataPros();
void Timer0Init();
void Timer1Init();

void main()
{
	P2=0x80;P0=0xff;P2=0x00;
	P2=0xa0;P0=0x00;P2=0x00;
	Timer0Init();
	Timer1Init();
	
}

