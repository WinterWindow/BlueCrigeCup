#include <STC15F2K60S2.H>
#include "stdio.h"
#include "UART.h"
unsigned char num=0;
unsigned char AD=10;
unsigned char DA=22;
unsigned char Uart_Buf[12];
void Uart_SendString(unsigned char *p);
void Uart_Loop();

void main()
{
	UartInit();
	EA=1;
	ES=1;
	while(1)
	{
		Uart_Loop();
	}
}
void Uart_SendString(unsigned char *p)
{
	while(*p!='\0')
	{
		SBUF=*p;
		while(TI==0);
		TI=0;
		p++;
	}
}
void Uart_Loop()
{
	if(num>0)
	{
		if(Uart_Buf[num-1]==0x0a)
		{
			if((Uart_Buf[0]=='S')&&(Uart_Buf[1]=='T')&&(Uart_Buf[2]==0x0d))
			{
				sprintf(Uart_Buf,"$%02u,%02u\r\n",(unsigned int)AD,(unsigned int)DA);
				Uart_SendString(Uart_Buf);
			}
			else if((Uart_Buf[0]=='P')&&(Uart_Buf[1]=='A')&&(Uart_Buf[2]=='R')&&(Uart_Buf[3]=='A')&&(Uart_Buf[4]==0x0d))
			{
				sprintf(Uart_Buf,"$%02u,%02u\r\n",(unsigned int)DA,(unsigned int)AD);
				Uart_SendString(Uart_Buf);
			}
			else 
			{
				sprintf(Uart_Buf,"ERROR\r\n");
				Uart_SendString(Uart_Buf);
			}
			num=0;
			
		}
		else 
			{
				if(num==7)
				{
					Uart_SendString("ERROR\r\n");
					num=0;
				}
			}
	}
}
void Uart_R() interrupt 4
{
	if(RI)
	{
		Uart_Buf[num++]=SBUF;
		RI=0;
	}
}