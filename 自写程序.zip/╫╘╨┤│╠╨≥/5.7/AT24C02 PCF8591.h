#ifndef __AT24C02PCF8591_H__
#define __AT24C02PCF8591_H__
void AT24C02_WriteByte(unsigned char Address,Data);
unsigned char AT24C02_ReadByte(unsigned char Address);
void PCF8591_WriteByte(unsigned char Data);
unsigned char PCF8591_ReadByte(unsigned char Address);
void Delay(unsigned char xms);
#endif
