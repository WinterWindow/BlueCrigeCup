#include <STC15F2K60S2.H>
#include "Timer0.h"
#include "Nixie.h"
#include "DS1302.h"
bit flag1=0,flag2=0;
unsigned int count2;

unsigned char Key,KN;
unsigned char TKN;

float T;

unsigned char KeyN();
unsigned char GetState();
void Key_Loop();

void main()
{
	Timer0Init();
	DS1302_Init();
	SetTime();
	while(1)
	{
		ReadTime();
		SetBuf(1,DS1302_Time[0]/10%10);
		SetBuf(2,DS1302_Time[0]%10);
		
		SetBuf(4,DS1302_Time[1]/10%10);
		SetBuf(5,DS1302_Time[1]%10);
		
		SetBuf(7,DS1302_Time[2]/10%10);
		SetBuf(8,DS1302_Time[2]%10);
		
		Nixie_Loop();
	}
}
unsigned char KeyN()
{
	unsigned char Temp;
	Temp=Key;
	Key=0;
	return Temp;
}
unsigned char GetState()
{
	unsigned char State=0;
	if(P30==0)State=7;
	if(P31==0)State=6;
	if(P32==0)State=5;
	if(P33==0)State=4;
	return State;
}
void Key_Loop()
{
	static unsigned char Now,Last;
	Last=Now;
	Now=GetState();
	
	if(count2<1000)
	{
		if(Now==0&&Last==7)Key=7;
		if(Now==0&&Last==6)Key=6;
		if(Now==0&&Last==5)Key=5;
		if(Now==0&&Last==4)Key=4;	
	}
	else
	{
		if(Now==0&&Last==7)Key=17;
		if(Now==0&&Last==6)Key=16;
		if(Now==0&&Last==5)Key=15;
		if(Now==0&&Last==4)Key=14;		
	}
	if(Last==0&&Now)flag1=1;
	if(Now==0&&Last)flag1=0;
}

void Timer0_R() interrupt 1
{
	static unsigned char count1,count3;
	TL0 = 0x20;		//���ö�ʱ��ֵ
	TH0 = 0xD1;		//���ö�ʱ��ֵ
	count1++;
	count3++;
	if(count1>20)
	{
		count1=0;
		Key_Loop();
	}
	if(count3>200)
	{
		count3=0;
		flag2=1;
	}
	else
		flag2=0;
	if(flag1)
	{
		count2++;
	}
	else
		count2=0;
	
}
