#ifndef __NIXIE_H__
#define __NIXIE_H__
void SetBuf(unsigned char Location,Number);
void Nixie_Loop();
#endif